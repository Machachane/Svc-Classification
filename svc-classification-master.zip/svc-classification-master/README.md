# svc-classification
 Support vector machine text classification - 20newsgroups dataset
